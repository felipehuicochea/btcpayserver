namespace BTCPayServer.Plugins.SimpleSwap.Views
{
    public static class PluginNavPages
    {
        public static string Index => "Index";
    }
} 